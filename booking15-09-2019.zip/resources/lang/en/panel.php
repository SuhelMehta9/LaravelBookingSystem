<?php

return [
    'site_title' => 'booking',
];
